<?php
$aplikasi[1] = 'gtAkademik';
$aplikasi[2] = 'gtFinansi';
$aplikasi[3] = 'gtPerizinan';
$aplikasi[4] = 'eCampuz';
$aplikasi[5] = 'eOviz';


$i = 1;
$total = 50;

while($i <= $total) {
	if  ($i%3 == 0){
		echo 'Foo ';
	} elseif ($i%5 == 0) {
		echo 'Bar ';
	} elseif ($i%3 == 0 AND $i%5 == 0) {
		echo 'FooBar ';
	} else {
		echo $i.' ';
	}
	$i++;
}

?>
