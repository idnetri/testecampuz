<?php
$aplikasi[1] = 'gtAkademik';
$aplikasi[2] = 'gtFinansi';
$aplikasi[3] = 'gtPerizinan';
$aplikasi[4] = 'eCampuz';
$aplikasi[5] = 'eOviz';


$x = 1;
$total = count($aplikasi);

while($x <= $total) {
  echo $aplikasi[$x].' ';
  $x++;
}

?>