<?php
function bagi($a,$b) {
  return intval($a/$b);
}

echo 'Hasil Bagi 7:2 dengan function = '.bagi(7,2); 
?>